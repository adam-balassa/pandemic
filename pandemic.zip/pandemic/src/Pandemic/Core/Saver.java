package Pandemic.Core;

public interface Saver {
    void save();
    Game load();
}
